package com.boa.kyc.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.boa.kyc.models.Customer;
import com.boa.kyc.services.CustomerService;

@RestController
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	
	@PostMapping("/addcustomer")
	public @ResponseBody Customer insertCustomer(@RequestBody Customer customer)
	{
		
		return customerService.addCustomer(customer);
	}
	
	@GetMapping("/getallcustomers")
	public List<Customer> getAllCustomers()
	{
		return customerService.getAllCustomers();
	}
	
	@GetMapping("/getcustomerbyid/{id}")
	public Customer getCustomerById(@PathVariable("id") int id)
	{
		return customerService.getCustomerById(id);
	}
	@GetMapping("/getcustomerbyname/{fname}")
	public List<Customer> getCustomerByName(@PathVariable("fname") String fname)
	{
		return customerService.getCustomerByFirstName(fname);
	}
	
	@PutMapping("/updatecustomer/{id}")
	public Customer updateCustomer(@PathVariable("id") int id, @RequestBody Customer customer)
	{
		
		Customer existing = customerService.getCustomerById(id);
		
		existing.setFirstName(customer.getFirstName());
		existing.setLastName(customer.getLastName());
		existing.setDob(customer.getDob());
		//save or update
		return customerService.addCustomer(existing);
		
		
	}
}
