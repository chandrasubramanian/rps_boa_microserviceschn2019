package com.boa.kyc.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boa.kyc.models.Appointment;
import com.boa.kyc.models.AppointmentSQL;

public interface AppointmentSQLRepo extends JpaRepository<AppointmentSQL,Integer> {

}
