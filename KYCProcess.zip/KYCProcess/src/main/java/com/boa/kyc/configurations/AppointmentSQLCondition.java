package com.boa.kyc.configurations;

import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

public class AppointmentSQLCondition implements Condition{

	@Override
	public boolean matches(ConditionContext arg0, AnnotatedTypeMetadata arg1) {
		// TODO Auto-generated method stub
		String type=System.getProperty("dbType");
		return (type != null && type.equalsIgnoreCase("MySQL"));
	}

}
