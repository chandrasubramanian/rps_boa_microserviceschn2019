package com.boa.kyc.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.boa.kyc.models.Appointment;

public interface AppointmentRepo extends MongoRepository<Appointment,Integer>{

}
