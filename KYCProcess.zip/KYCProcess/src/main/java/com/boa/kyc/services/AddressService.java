package com.boa.kyc.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.kyc.models.Address;
import com.boa.kyc.models.Customer;
import com.boa.kyc.repositories.AddressRepo;
import com.boa.kyc.repositories.CustomerRepo;

@Service
public class AddressService {
    @Autowired
	private CustomerService customerService;
    @Autowired
    private AddressRepo addressRepo;
    
  //insert address object
  	public Address addAddress(int id, Address address)
  	{
  		Customer cust = customerService.getCustomerById(id);
  		address.setCustomer(cust);
  		return addressRepo.save(address);
  		
  	}
  	
  	//select all
  	public List<Address> getAllAddress()
  	{
  		return addressRepo.findAll();
  	}
  	
  	
	
}
