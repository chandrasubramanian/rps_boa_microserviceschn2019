package com.boa.kyc.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Appointment")
public class AppointmentSQL {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="Appointment_Id")
	private int appointmentId;
    @Column(name="From_Time",nullable=false)
	private String fromTime;
    @Column(name="To_Time",nullable=false)
	private String toTime;
    @Column(name="Venue",nullable=false)
	private String venue;
    @Column(name="Agenda",nullable=false)
	private String agenda;
	public int getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(int appointmentId) {
		this.appointmentId = appointmentId;
	}
	public String getFromTime() {
		return fromTime;
	}
	public void setFromTime(String fromTime) {
		this.fromTime = fromTime;
	}
	public String getToTime() {
		return toTime;
	}
	public void setToTime(String toTime) {
		this.toTime = toTime;
	}
	public String getVenue() {
		return venue;
	}
	public void setVenue(String venue) {
		this.venue = venue;
	}
	public String getAgenda() {
		return agenda;
	}
	public void setAgenda(String agenda) {
		this.agenda = agenda;
	}
    
    
    
}
