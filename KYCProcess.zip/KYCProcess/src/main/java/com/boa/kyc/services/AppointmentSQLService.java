package com.boa.kyc.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.kyc.models.Appointment;
import com.boa.kyc.models.AppointmentSQL;
import com.boa.kyc.repositories.AppointmentRepo;
import com.boa.kyc.repositories.AppointmentSQLRepo;
@Service
public class AppointmentSQLService {
	@Autowired
	private AppointmentSQLRepo repo;
	
	public AppointmentSQL addAppointment(AppointmentSQL appointment)
	{
		return  repo.save(appointment);
	}
	
	public List<AppointmentSQL> getAllAppointments()
	{
		return repo.findAll();
	}
	
}
