package com.boa.kyc.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.kyc.models.Appointment;
import com.boa.kyc.repositories.AppointmentRepo;

@Service
public class AppointmentService {

	@Autowired
	private AppointmentRepo repo;
	
	public Appointment addAppointment(Appointment appointment)
	{
		return  repo.save(appointment);
	}
	
	public List<Appointment> getAllAppointments()
	{
		return repo.findAll();
	}
	
}
