package com.boa.kyc.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.kyc.models.Customer;
import com.boa.kyc.repositories.CustomerRepo;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepo customerRepo;
	
	//insert customer object
	public Customer addCustomer(Customer customer)
	{
		return customerRepo.save(customer);
	}
	
	//select all
	public List<Customer> getAllCustomers()
	{
		return customerRepo.findAll();
	}
	//select with where
	
	public Customer getCustomerById(int id)
	{
		return customerRepo.findById(id).orElse(null);
	}
	//select with where name
	
		public List<Customer> getCustomerByFirstName(String fname)
		{
			return customerRepo.findByName(fname);
		}
	
}
