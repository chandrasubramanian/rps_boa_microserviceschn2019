package com.boa.kyc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.boa.kyc.models.Customer;

public interface CustomerRepo extends JpaRepository<Customer,Integer>{

	
	//@Modifying(clearAutomatically = true)
	@Query("select customer from Customer customer where customer.firstName =:fname")
	List<Customer> findByName(@Param("fname") String fname);
}
